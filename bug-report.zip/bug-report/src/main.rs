use slint::{self, Model, ModelExt, VecModel};
use std::error::Error;
use std::rc::Rc;

slint::include_modules!();

fn main() -> Result<(), Box<dyn Error>> {
    let ui = AppWindow::new()?;

    let languages = Rc::new(VecModel::from(vec![
        Language {
            code: "en".into(),
            name: "English".into(),
        },
        Language {
            code: "es".into(),
            name: "Spanish".into(),
        },
        Language {
            code: "fr".into(),
            name: "French".into(),
        },
        Language {
            code: "de".into(),
            name: "German".into(),
        },
    ]));

    let language_names = Rc::new(languages.clone().map(|lang: Language| lang.name.clone()));

    ui.set_language_names(language_names.into());
    //ui.set_lang1(languages.row_data(0).unwrap());
    //ui.set_lang2(languages.row_data(1).unwrap());

    ui.on_swap_languages({
        let ui_handle = ui.as_weak();
        move || {
            let ui = ui_handle.unwrap();
            let lang1 = ui.get_lang1();
            let lang2 = ui.get_lang2();

            println!("Before swap: lang1={:?}, lang2={:?}", lang1, lang2);
            ui.set_lang1(lang2);
            ui.set_lang2(lang1);

            let lang1_after = ui.get_lang1();
            let lang2_after = ui.get_lang2();
            println!("After swap: lang1={:?}, lang2={:?}", lang1_after, lang2_after);
        }
    });

    ui.on_select_lang1({
        let ui_handle = ui.as_weak();
        let languages = languages.clone();
        move |name| {
            let ui = ui_handle.unwrap();
            for i in 0..languages.row_count() {
                if let Some(lang) = languages.row_data(i) {
                    if lang.name == name {
                        println!("Selected lang1: {:?}", lang);
                        ui.set_lang1(lang);
                        break;
                    }
                }
            }
        }
    });

    ui.on_select_lang2({
        let ui_handle = ui.as_weak();
        let languages = languages.clone();
        move |name| {
            let ui = ui_handle.unwrap();
            for i in 0..languages.row_count() {
                if let Some(lang) = languages.row_data(i) {
                    if lang.name == name {
                        println!("Selected lang2: {:?}", lang);
                        ui.set_lang2(lang);
                        break;
                    }
                }
            }
        }
    });

    ui.run()?;

    Ok(())
}
