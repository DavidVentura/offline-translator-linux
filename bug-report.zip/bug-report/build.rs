fn main() {
    slint_build::compile("ui/app.slint").expect("Slint build failed");
}
